<?php 
	if(isset($_POST['submit'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$seat=$_POST['seat'];

		$to='agordon@thestudy.qc.ca';
		$subject='Matilda e-ticket';
		$message="Name: ".$name."\n"."Seat: ".$seat;
		$headers="From: ".$email;

		if(mail($to, $subject, $seat, $headers)){
			echo "<h1>Sent Successfully! Thank you"." ".$name.", Remember to bring 10$ to pay at the door.</h1>";
		}
		else{
			echo "Something went wrong!";
		}
	}

?>